import requests
import time
import telebot

BOT_TOKEN = "8385489660:AAFMy3NrrVXU1CjrzhrenWNa1JTK5JHkVAQ"
CHAT_ID = "1920237976"
BIRDEYE_API_KEY = "ebd1a969f27140408f8446ad470a0015"

bot = telebot.TeleBot(BOT_TOKEN)

BIRDEYE = "https://public-api.birdeye.so"
HEADERS = {
    "accept": "application/json",
    "x-chain": "solana",
    "X-API-KEY": BIRDEYE_API_KEY
}

def send(msg):
    bot.send_message(CHAT_ID, msg, parse_mode="Markdown")

def scan():
    url = f"{BIRDEYE}/defi/pairs"
    res = requests.get(url, headers=HEADERS).json()

    for p in res.get("data", []):
        try:
            name = p["token_name"]
            symbol = p["symbol"]
            token = p["token_address"]

            liquidity = p["liquidity"]
            buys = p["buys_1m"]

            if liquidity > 15000 and buys > 10:
                send(f"🚀 *New Alert!* {name} ({symbol})\n`{token}`")

        except:
            continue

print("Bot running...")
while True:
    try:
        scan()
        time.sleep(20)
    except:
        time.sleep(5)
